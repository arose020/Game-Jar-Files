
C A P T A I N  A N D R E W

        B   E   T   A

            v4.1


THANK YOU FOR DOWNLOADING!


ABOUT
______________________________________________________________________________

I am new to scripting and I made a more complicated program that I call Captain
Andrew

This took quite some time to get to where it is so give me a break

Every program needs good inspiration, so I took an  MMORPG game I used to play 
called realm of the mad (www.realmofthemadgod.com) and basicly recreated it.
Still a long ways to go from where its at now, but I have included a new 
getTile method, that if you look through the source code, you can see how it 
exactly works. look at the res folder too, youl find some cool stuff and even
if you dont have an IDE to view the files, at least look through the levels folder
in res.

You can view the .java files and .class files without an IDE however, upload
the source code folder to google drive and install the extention drive notepad or 
somthing similar that can view .java files


INSTRUCTIONS
______________________________________________________________________________

Double click to run

GOAL: explore and shoot

A-W-S-D to move

Mouse button pointing a direction to shoot

TROUBLESHOOTING
______________________________________________________________________________

If it doesnt run, you need JDK or an updated JRE, you can download it here

For most of you, just update your JRE, dont bother installing JDK

JDK http://www.oracle.com/technetwork/java/javase/downloads/jdk7-downloads-1880260.html

JRE http://java.com/en/download/index.jsp

You want the Windows x64 download unless your computer is x86... you can check
that by going to Control Panel>System and Security>System and under system
type it will say 64 bit opperating system or 86 bit opperating system. But
for most of you, it would be 64 bit.

LICENSE
______________________________________________________________________________

Coppywrite Andrew Rosenthal, All rights reserved

Feel free to acess my code...if you have an IDE and add, change, expplore etc.

Want an IDE? download elipse, google it.